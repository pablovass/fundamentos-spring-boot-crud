package com.pablovass.fundamentos.bean;

public interface MyBean {
    void print();
}
