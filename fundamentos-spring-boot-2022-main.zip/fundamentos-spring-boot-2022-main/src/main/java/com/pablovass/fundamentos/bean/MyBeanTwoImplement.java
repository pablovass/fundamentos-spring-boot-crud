package com.pablovass.fundamentos.bean;

public class MyBeanTwoImplement implements MyBean {
    @Override
   public void  print(){
        System.out.println("hola desde mi implementacion 2 propia del bean 2");
    }
}
