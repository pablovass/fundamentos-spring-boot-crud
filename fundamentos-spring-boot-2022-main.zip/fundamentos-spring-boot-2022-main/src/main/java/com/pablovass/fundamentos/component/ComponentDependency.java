package com.pablovass.fundamentos.component;

public interface ComponentDependency {
    void  saludar();
}
