package com.pablovass.fundamentos.bean;

public interface MyOperation {
    int sum(int number);
}
