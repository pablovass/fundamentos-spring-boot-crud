package com.pablovass.fundamentos.bean;

public interface MyBeanWithDependency {
    void printWithDependency();
}
