package com.pablovass.fundamentos.configuration;

public interface MyBeanWithProperties {
String function();
}
