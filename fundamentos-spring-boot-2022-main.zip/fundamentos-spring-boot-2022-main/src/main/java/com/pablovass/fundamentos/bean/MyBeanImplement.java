package com.pablovass.fundamentos.bean;

public class MyBeanImplement implements MyBean {
    @Override
   public void  print(){
        System.out.println("hola desde my bean implementado");
    }
}
